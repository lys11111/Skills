# shiki-wechat-summary-plus

微信群 / 私聊：**精华摘要 · 用户画像 · 记忆点 · 关系攻略**（恋爱、交友、拉群等）。依赖本机 [wx-cli](https://github.com/jackwener/wx-cli) 读取微信记录，数据不出本机。

## 发给别人的最小包

只需分享整个文件夹 **`shiki-wechat-summary-plus/`**（或同名 zip），内含 `SKILL.md`、`references/`、`scripts/`、`EXTEND.md.example`、本 README。

对方**不需要**你的 `wechat/` 聊天记录目录。

## 安装（3 步）

### 1. 放入 Cursor Skills 目录

任选一种（与 Cursor 版本/习惯一致即可）：

| 方式 | 路径 |
|------|------|
| **项目内**（推荐，可进 git） | 解压到 `<项目根>/.cursor/skills/shiki-wechat-summary-plus/` |
| **个人全局** | `%USERPROFILE%\.cursor\skills\shiki-wechat-summary-plus\` |
| **Agents 目录**（若你使用 `~/.agents/skills`） | `%USERPROFILE%\.agents\skills\shiki-wechat-summary-plus\` |

### 2. 安装并初始化 wx-cli

```powershell
npm install -g @jackwener/wx-cli
```

微信 4.x **已登录** 时（管理员 PowerShell，注意账号风险说明见 wx-cli README）：

```powershell
wx init
wx daemon start
wx sessions --json --limit 5
```

### 3. 首次配置 EXTEND.md

复制 `EXTEND.md.example` 为下面**任一**路径（先找到的生效）：

- `<项目根>/.shiki-skills/shiki-wechat-summary-plus/EXTEND.md`
- `%USERPROFILE%\.shiki-skills\shiki-wechat-summary-plus\EXTEND.md`

必改两项：

```yaml
self_wxid: wxid_你的id
self_display: 你的昵称
data_root: D:\你想存放报告的目录\wechat   # 可选，默认项目下 wechat
```

`self_wxid` 可用 `wx contacts --query "你的昵称" --json` 查看。

## 怎么用

在 Cursor 对话里说（Agent 会自动匹配本 skill）：

- `用 shiki 总结 XX 群最近 7 天，带攻略`
- `总结和小红的私聊，更新记忆点`
- `给群里的 XXX 写一份拉群攻略`
- `分析文件传输助手里的备忘`

## 输出目录结构（在 data_root 下）

```
wechat/
├── {群id}-{群名}/
│   ├── YYYY-MM-DD.md      # 群精华+
│   ├── profiles/          # 群友画像
│   ├── memory/            # 记忆点 yaml
│   └── playbook-*.md      # 单人攻略
└── private/{wxid}-{昵称}/
    ├── memory.md
    └── playbook.md
```

## 前置依赖

- Windows / macOS 微信桌面版 + **wx-cli**
- **不要**把 `wechat/` 提交到公开仓库（含聊天摘要）

## 与 baoyu-wechat-summary 区别

| 功能 | shiki+ | baoyu |
|------|--------|-------|
| 群聊精华 | 有 | 有 |
| 毒舌版 | 默认关 | 可选 |
| 记忆点 / 送礼 / 生日 | 有 | 无 |
| 恋爱交友攻略 | 有 | 无 |
| 私聊一等公民 | 有 | 弱 |

## 校验记忆文件（可选）

```bash
python .cursor/skills/shiki-wechat-summary-plus/scripts/validate-memory.py path/to/memory.yaml
```

## 许可与免责

Skill 文档仅供个人学习使用；请遵守微信用户协议与 wx-cli 风险说明；生成的社交建议需人工判断，禁止用于骚扰或 PUA。
